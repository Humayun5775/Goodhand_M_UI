import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-select-staff',
  templateUrl: './select-staff.component.html',
  styleUrls: ['./select-staff.component.css']
})
export class SelectStaffComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
