import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assign-me-preferred-professional',
  templateUrl: './assign-me-preferred-professional.component.html',
  styleUrls: ['./assign-me-preferred-professional.component.css']
})
export class AssignMePreferredProfessionalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
