import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-saved-payment-details',
  templateUrl: './saved-payment-details.component.html',
  styleUrls: ['./saved-payment-details.component.css']
})
export class SavedPaymentDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
