import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-what-is-mirrors',
  templateUrl: './what-is-mirrors.component.html',
  styleUrls: ['./what-is-mirrors.component.css']
})
export class WhatIsMirrorsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
