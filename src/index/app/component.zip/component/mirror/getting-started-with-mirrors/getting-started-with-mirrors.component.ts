import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-getting-started-with-mirrors',
  templateUrl: './getting-started-with-mirrors.component.html',
  styleUrls: ['./getting-started-with-mirrors.component.css']
})
export class GettingStartedWithMirrorsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
