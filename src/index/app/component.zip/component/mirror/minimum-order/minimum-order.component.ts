import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-minimum-order',
  templateUrl: './minimum-order.component.html',
  styleUrls: ['./minimum-order.component.css']
})
export class MinimumOrderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
