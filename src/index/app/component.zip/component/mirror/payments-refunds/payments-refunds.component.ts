import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payments-refunds',
  templateUrl: './payments-refunds.component.html',
  styleUrls: ['./payments-refunds.component.css']
})
export class PaymentsRefundsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
