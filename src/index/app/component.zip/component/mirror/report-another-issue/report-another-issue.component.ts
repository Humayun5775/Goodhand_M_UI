import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-another-issue',
  templateUrl: './report-another-issue.component.html',
  styleUrls: ['./report-another-issue.component.css']
})
export class ReportAnotherIssueComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
