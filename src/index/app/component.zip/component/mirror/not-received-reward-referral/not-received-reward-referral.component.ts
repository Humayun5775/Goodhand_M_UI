import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-not-received-reward-referral',
  templateUrl: './not-received-reward-referral.component.html',
  styleUrls: ['./not-received-reward-referral.component.css']
})
export class NotReceivedRewardReferralComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
