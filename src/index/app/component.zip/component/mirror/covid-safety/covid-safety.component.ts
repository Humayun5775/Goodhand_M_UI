import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-covid-safety',
  templateUrl: './covid-safety.component.html',
  styleUrls: ['./covid-safety.component.css']
})
export class CovidSafetyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
