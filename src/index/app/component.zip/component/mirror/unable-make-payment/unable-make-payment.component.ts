import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unable-make-payment',
  templateUrl: './unable-make-payment.component.html',
  styleUrls: ['./unable-make-payment.component.css']
})
export class UnableMakePaymentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
