import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-not-happy-service-experience',
  templateUrl: './not-happy-service-experience.component.html',
  styleUrls: ['./not-happy-service-experience.component.css']
})
export class NotHappyServiceExperienceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
