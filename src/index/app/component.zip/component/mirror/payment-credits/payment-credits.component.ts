import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment-credits',
  templateUrl: './payment-credits.component.html',
  styleUrls: ['./payment-credits.component.css']
})
export class PaymentCreditsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
