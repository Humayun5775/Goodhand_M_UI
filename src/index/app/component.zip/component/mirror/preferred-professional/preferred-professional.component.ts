import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-preferred-professional',
  templateUrl: './preferred-professional.component.html',
  styleUrls: ['./preferred-professional.component.css']
})
export class PreferredProfessionalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
