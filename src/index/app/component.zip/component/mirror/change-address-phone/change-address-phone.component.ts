import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-change-address-phone',
  templateUrl: './change-address-phone.component.html',
  styleUrls: ['./change-address-phone.component.css']
})
export class ChangeAddressPhoneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
