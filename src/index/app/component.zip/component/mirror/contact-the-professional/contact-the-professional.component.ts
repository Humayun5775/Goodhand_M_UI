import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact-the-professional',
  templateUrl: './contact-the-professional.component.html',
  styleUrls: ['./contact-the-professional.component.css']
})
export class ContactTheProfessionalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
