import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-check-professional-vaccinated',
  templateUrl: './check-professional-vaccinated.component.html',
  styleUrls: ['./check-professional-vaccinated.component.css']
})
export class CheckProfessionalVaccinatedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
