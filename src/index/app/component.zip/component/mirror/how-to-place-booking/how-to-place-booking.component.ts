import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-how-to-place-booking',
  templateUrl: './how-to-place-booking.component.html',
  styleUrls: ['./how-to-place-booking.component.css']
})
export class HowToPlaceBookingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
