import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-preferred-slots-not-availble',
  templateUrl: './preferred-slots-not-availble.component.html',
  styleUrls: ['./preferred-slots-not-availble.component.css']
})
export class PreferredSlotsNotAvailbleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
