import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-see-payment-details',
  templateUrl: './see-payment-details.component.html',
  styleUrls: ['./see-payment-details.component.css']
})
export class SeePaymentDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
