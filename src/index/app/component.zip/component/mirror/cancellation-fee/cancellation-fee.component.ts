import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cancellation-fee',
  templateUrl: './cancellation-fee.component.html',
  styleUrls: ['./cancellation-fee.component.css']
})
export class CancellationFeeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
