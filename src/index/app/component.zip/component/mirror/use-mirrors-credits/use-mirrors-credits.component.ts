import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-use-mirrors-credits',
  templateUrl: './use-mirrors-credits.component.html',
  styleUrls: ['./use-mirrors-credits.component.css']
})
export class UseMirrorsCreditsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
