import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-remove-service-booking',
  templateUrl: './add-remove-service-booking.component.html',
  styleUrls: ['./add-remove-service-booking.component.css']
})
export class AddRemoveServiceBookingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
