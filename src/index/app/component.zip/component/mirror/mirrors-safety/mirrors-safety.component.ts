import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mirrors-safety',
  templateUrl: './mirrors-safety.component.html',
  styleUrls: ['./mirrors-safety.component.css']
})
export class MirrorsSafetyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
