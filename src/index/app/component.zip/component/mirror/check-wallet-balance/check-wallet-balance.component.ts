import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-check-wallet-balance',
  templateUrl: './check-wallet-balance.component.html',
  styleUrls: ['./check-wallet-balance.component.css']
})
export class CheckWalletBalanceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
