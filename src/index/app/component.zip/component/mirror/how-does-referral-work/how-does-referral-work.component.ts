import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-how-does-referral-work',
  templateUrl: './how-does-referral-work.component.html',
  styleUrls: ['./how-does-referral-work.component.css']
})
export class HowDoesReferralWorkComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
