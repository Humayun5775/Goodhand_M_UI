import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-can-i-rebook-the-same-professional',
  templateUrl: './can-i-rebook-the-same-professional.component.html',
  styleUrls: ['./can-i-rebook-the-same-professional.component.css']
})
export class CanIRebookTheSameProfessionalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
