import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-preferred-professional-not-visible',
  templateUrl: './preferred-professional-not-visible.component.html',
  styleUrls: ['./preferred-professional-not-visible.component.css']
})
export class PreferredProfessionalNotVisibleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
