import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mirrors-membership',
  templateUrl: './mirrors-membership.component.html',
  styleUrls: ['./mirrors-membership.component.css']
})
export class MirrorsMembershipComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
