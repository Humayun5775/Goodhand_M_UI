import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-validity-rewards',
  templateUrl: './validity-rewards.component.html',
  styleUrls: ['./validity-rewards.component.css']
})
export class ValidityRewardsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
