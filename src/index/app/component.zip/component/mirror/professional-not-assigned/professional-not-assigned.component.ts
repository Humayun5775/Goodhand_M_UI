import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-professional-not-assigned',
  templateUrl: './professional-not-assigned.component.html',
  styleUrls: ['./professional-not-assigned.component.css']
})
export class ProfessionalNotAssignedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
