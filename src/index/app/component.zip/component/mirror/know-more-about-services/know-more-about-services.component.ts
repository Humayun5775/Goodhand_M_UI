import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-know-more-about-services',
  templateUrl: './know-more-about-services.component.html',
  styleUrls: ['./know-more-about-services.component.css']
})
export class KnowMoreAboutServicesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
